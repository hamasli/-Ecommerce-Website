from django.contrib import admin
from django.urls import path,include;
from products.views import *;


urlpatterns = [
  path('<slug>/',get_products,name="get_products"),
]